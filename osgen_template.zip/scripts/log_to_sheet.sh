#!/bin/bash
source $(dirname "$0")/../.env

if [[ -z "$SHEET_WEBAPP_URL" ]]; then
  echo "❌ SHEET_WEBAPP_URL belum diatur. Edit file .env terlebih dahulu."
  exit 1
fi

read -p "Apa yang kamu bangun hari ini? " build
read -p "Apa yang kamu monetisasi atau pasarkan? " monetize
read -p "Ide baru yang ditemukan? " explore

json_payload=$(jq -n         --arg build "$build"         --arg monetize "$monetize"         --arg explore "$explore"         '{build:$build, monetize:$monetize, explore:$explore}')

curl -s -X POST -H "Content-Type: application/json"          -d "$json_payload"          "$SHEET_WEBAPP_URL"

echo "✅ Log terkirim ke Google Sheet!"
