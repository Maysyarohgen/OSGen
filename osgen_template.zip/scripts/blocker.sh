#!/bin/bash
echo "🛡️ Mengaktifkan mode fokus brutal..."
DISTRACTIONS="youtube.com facebook.com tiktok.com reddit.com twitter.com instagram.com"
for site in $DISTRACTIONS; do
  if ! grep -q "$site" /etc/hosts; then
    echo "127.0.0.1 $site" | sudo tee -a /etc/hosts >/dev/null
  fi
done
echo "🚫 Distraksi diblokir!"
