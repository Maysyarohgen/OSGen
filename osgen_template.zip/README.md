# OSGen

**OSGen** adalah _coding operating system_ berbasis CLI untuk menjaga produktivitas brutal
para developer yang ingin membangun dan memonetisasi produk digital tanpa perlu menunjukkan wajah.

Fitur utama:
- Prompt harian & checklist
- Local progress log
- Pemblokir distraksi
- Push Telegram harian
- Log tracker langsung ke Google Sheet

## Instalasi Singkat

```bash
git clone https://github.com/kamu/osgen
cd osgen
chmod +x install.sh
./install.sh
```

Pastikan sudah meng‑install **Go** (untuk _linik_), serta `jq` dan `curl`.
