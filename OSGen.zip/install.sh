#!/bin/bash
set -e
echo "🔧 Memulai instalasi OSGen dengan Telegram & Google Sheet..."

# Step 0: check dependencies
if ! command -v curl &>/dev/null; then
  echo "❌ 'curl' tidak ditemukan. Install dulu."
  exit 1
fi
if ! command -v jq &>/dev/null; then
  echo "❌ 'jq' tidak ditemukan. Install dulu (contoh: sudo apt install jq)."
  exit 1
fi

# Step 1: install linik if missing
if ! command -v linik &> /dev/null; then
    echo "📦 Linik belum terpasang. Menginstall..."
    if command -v go &> /dev/null; then
        go install github.com/linikern/linik@latest
        export PATH=$PATH:$(go env GOPATH)/bin
    else
        echo "❌ Go tidak ditemukan. Silakan install Go terlebih dahulu."
        exit 1
    fi
else
    echo "✅ Linik sudah terpasang."
fi

# Step 2: clone repo if executed outside of repo
if [ ! -f "linik.yml" ]; then
    echo "📥 Meng-clone OSGen..."
    git clone https://github.com/kamu/osgen.git
    cd osgen
fi

# Step 3: set permissions
echo "🔐 Mengatur izin eksekusi..."
chmod +x scripts/*.sh

# Step 4: config env
if [ -f ".env" ]; then
  echo "📝 File .env sudah ada, lewati."
else
  read -p "Masukkan BOT_TOKEN Telegram: " BOT_TOKEN
  read -p "Masukkan CHAT_ID Telegram: " CHAT_ID
  read -p "Masukkan Google Sheet WebApp URL: " SHEET_WEBAPP_URL

  cat <<EOF > .env
BOT_TOKEN="$BOT_TOKEN"
CHAT_ID="$CHAT_ID"
SHEET_WEBAPP_URL="$SHEET_WEBAPP_URL"
EOF
  echo "✅ File .env dibuat."
fi

# Step 5: add alias
SHELL_RC="$HOME/.bashrc"
[[ $SHELL == *zsh ]] && SHELL_RC="$HOME/.zshrc"

if ! grep -q "alias osgen=" "$SHELL_RC"; then
  echo "🔗 Menambahkan alias 'osgen' ke terminal..."
  echo "alias osgen='cd $(pwd) && linik start'" >> "$SHELL_RC"
fi

echo ""
echo "🎉 Instalasi OSGen selesai!"
echo "🔁 Restart terminal, lalu ketik: osgen"
