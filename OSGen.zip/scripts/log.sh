#!/bin/bash
source $(dirname "$0")/../.env 2>/dev/null || true

read -p "Apa yang kamu bangun hari ini? " build
read -p "Apa yang kamu monetisasi atau pasarkan? " monetize
read -p "Ide baru yang ditemukan? " explore

log_entry="$(date): 🔨 $build | 💸 $monetize | 💡 $explore"
echo "$log_entry" >> ~/osgen-daily.log
echo "✅ Progress dicatat di ~/osgen-daily.log"
