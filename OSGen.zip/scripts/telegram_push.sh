#!/bin/bash
source $(dirname "$0")/../.env

if [[ -z "$BOT_TOKEN" || -z "$CHAT_ID" ]]; then
  echo "❌ BOT_TOKEN atau CHAT_ID belum diatur. Edit file .env terlebih dahulu."
  exit 1
fi

MESSAGE="🚀 OSGen Daily Prompt:%0A☑ Build. ☑ Monetize. ☑ Explore.%0A⚔️ Fokus atau hilang!"
curl -s -X POST "https://api.telegram.org/bot${BOT_TOKEN}/sendMessage"          -d chat_id="${CHAT_ID}"          -d text="${MESSAGE}"          -d parse_mode="Markdown"
echo "✅ Prompt terkirim ke Telegram."
